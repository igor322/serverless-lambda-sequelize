# Projeto Lambda
Funções lambda, serverless, utilizando banco de dados postgreSQl RDS da Amazon Services.